(function () {



/* Exports */
Package._define("templating-runtime");

})();
