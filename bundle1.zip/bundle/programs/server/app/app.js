var require = meteorInstall({"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
serverlist = new Mongo.Collection("serverlist");
serverlist.insert({
  name: "chetan"
});
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsInN0YXJ0dXAiLCJzZXJ2ZXJsaXN0IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaW5zZXJ0IiwibmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0gsU0FBT0ksQ0FBUCxFQUFTO0FBQUNKLGFBQU9JLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFFWEosT0FBT0ssT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZEO0FBS0FDLGFBQVcsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixZQUFyQixDQUFYO0FBQ0FGLFdBQVdHLE1BQVgsQ0FBa0I7QUFBQ0MsUUFBSztBQUFOLENBQWxCLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcblxuXG5zZXJ2ZXJsaXN0PW5ldyBNb25nby5Db2xsZWN0aW9uKFwic2VydmVybGlzdFwiKTtcbnNlcnZlcmxpc3QuaW5zZXJ0KHtuYW1lOlwiY2hldGFuXCJ9KTtcbiJdfQ==
